//
//  SecondVC.swift
//  DataPassThroughSegueSender
//
//  Created by agile on 22/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit

class SecondVC: UIViewController {

    
    var finalName : String = ""
    
    
    @IBOutlet var labelOfSecondVC: UILabel!
    
   
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        labelOfSecondVC.text = finalName
        
        
        // Do any additional setup after loading the view.
    }

    

   

}
