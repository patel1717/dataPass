//
//  ViewController.swift
//  DataPassThroughSegueSender
//
//  Created by agile on 22/08/18.
//  Copyright © 2018 neeall. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var textFieldOfFirstVC: UITextField!
   
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

   
    
    
    @IBAction func buttonSendToSecondVC(_ sender: Any) {
        
        
        self.performSegue(withIdentifier: "segueFromFirstVCToSecondVC", sender: textFieldOfFirstVC.text)
        
        
    }

    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! SecondVC
        vc.finalName = sender as! String
    }
    
    

}

